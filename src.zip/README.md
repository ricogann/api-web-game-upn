# API Backend AliceWeb

## Step 1
Clone Repository

## Step 2
```
npm install
```

## Step 3
```
npm run dev
```

## Documentation POSTMAN
https://documenter.getpostman.com/view/21361511/2s9Y5SVk9k
